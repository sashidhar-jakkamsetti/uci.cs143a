#if !defined(__VGA_H__)
#define __VGA_H__

void vgainit(void);
void printvga(char *);

#endif